# 1.5 Sistema de mensagens

### Estruturas de dados usadas:
* users : Set com todos os nomes dos users do sistema;
* [username]Following : Set com os nomes dos users que o username segue;  
* [username]Messages : List com todas as mensagens enviadas por o username
