## 1.2 Comandos usados para carregar o ficheiro no Redis

sudo cat names_counting.txt | redis-cli --pipe